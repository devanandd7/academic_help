/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.experiment_4.service;

import com.mycompany.experiment_4.model.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author kumar
 */
public class UserServices {

    private static final SessionFactory factory;

    static {
        factory = new Configuration().configure("Hibernate.cfg.xml").addAnnotatedClass(User.class).buildSessionFactory();
    }

    public static void saveUsers(User user) {
        Session session = factory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        session.persist(user);
        transaction.commit();
    }
}
