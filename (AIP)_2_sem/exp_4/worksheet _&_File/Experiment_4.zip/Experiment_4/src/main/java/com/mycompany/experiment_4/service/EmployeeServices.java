/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.experiment_4.service;

import com.mycompany.experiment_4.model.Employee;
import com.mycompany.experiment_4.model.EmployeeDetails;
import com.mycompany.experiment_4.model.EmployeeDTO;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import java.util.List;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author kumar
 */
public class EmployeeServices {

    private static final SessionFactory factory;

    static {
        factory = new Configuration().configure("Hibernate.cfg.xml").addAnnotatedClass(Employee.class).buildSessionFactory();
    }

    public static void saveEmployee(Employee employee, EmployeeDetails employeeDetails) {
        Session session = factory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        employee.setEmployeeDetails(employeeDetails);
        session.persist(employee);
        transaction.commit();
    }

    public static List<Employee> getAllEmployees() {
        Session session = factory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        List<Employee> employees = session.createQuery("from Employee", Employee.class).getResultList();
        transaction.commit();
        return employees;
    }

    public static List<EmployeeDTO> getAllEmployeeDAO() {
        Session session = factory.getCurrentSession();
        Transaction transaction = session.beginTransaction();

        List<EmployeeDTO> employees = session.createQuery(
                "SELECT new com.mycompany.experiment_4.model.EmployeeDTO (e.id , e.name , e.department , e.salary , d.phone , d.address) "
                + "from Employee e join EmployeeDetails d ON e.id = d.id", EmployeeDTO.class).getResultList();

        transaction.commit();
        return employees;
    }

    public Employee getEmployee(int employeeId) {
        Session session = factory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        Employee employee = session.get(Employee.class, employeeId);
        transaction.commit();
        return employee;
    }

    public static void updateEmployee(int id, String name, String department, double salary) {
        Session session = factory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        Employee employee = session.get(Employee.class, id);
        if (employee != null) {
            employee.setName(name);
            employee.setDepartment(department);
            employee.setSalary(salary);
            session.merge(employee);
        }
        transaction.commit();
    }

    public static void deleteEmployee(int employeeId) {
        Session session = factory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        Employee employee = session.get(Employee.class, employeeId);
        session.remove(employee);
        transaction.commit();
    }

    public static List<EmployeeDetails> getEmployeeDetails() {
        Session session = factory.getCurrentSession();
        Transaction transaction = session.beginTransaction();
        List<EmployeeDetails> details = session.createQuery("from EmployeeDetails", EmployeeDetails.class).getResultList();
        transaction.commit();
        return details;
    }
}
