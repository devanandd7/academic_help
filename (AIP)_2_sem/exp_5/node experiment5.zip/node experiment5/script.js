// Fetch and display all student data
async function fetchStudents() {
    const response = await fetch("http://localhost:3000/");
    const students = await response.json();

    const table = document.getElementById("student-table");
    table.innerHTML = "";
    students.forEach(student => {
        table.innerHTML += `
            <tr>
                <td>${student.id}</td>
                <td>${student.student_uid}</td>
                <td>${student.student_name}</td>
                <td>${student.mob_no}</td>
                <td>${student.student_email}</td>
                <td>${student.student_address}</td>
            </tr>
        `;
    });
}

// Load profile details
async function loadProfile() {
    const response = await fetch("http://localhost:3000/");
    const students = await response.json();

    if (students.length > 0) {
        const student = students[0]; // Example: Load the first student
        document.getElementById("profile-name").textContent = student.student_name;
        document.getElementById("profile-mobile").textContent = student.mob_no;
        document.getElementById("profile-email").textContent = student.student_email;
        document.getElementById("profile-address").textContent = student.student_address;
    }
}

// Show edit form
function editProfile() {
    document.getElementById("edit-form").style.display = "block";
}

// Save edited profile
async function saveProfile() {
    const name = document.getElementById("edit-name").value;
    const mobile = document.getElementById("edit-mobile").value;
    const email = document.getElementById("edit-email").value;
    const address = document.getElementById("edit-address").value;

    const response = await fetch("http://localhost:3000/update/1", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ student_uid: 1, student_name: name, mob_no: mobile, student_email: email, student_address: address }),
    });

    if (response.ok) {
        alert("Profile Updated!");
        window.location.reload();
    } else {
        alert("Failed to update profile.");
    }
}

// Load data on page load
if (document.title.includes("Profile")) {
    loadProfile();
} else {
    fetchStudents();
}
