const mysql = require("mysql2");

// Create a connection to the database  
const db = mysql.createPool({
  host: "127.0.0.1",
  user: "root",
  password: "password", // Replace with your actual password
  database: "experiment5aip",
}).promise(); // Use promise-based queries

// Table creation query (Fixed missing closing parenthesis)
const query_create_and_check_database = `
  CREATE TABLE IF NOT EXISTS student_exp5 (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_uid INT UNIQUE,
    student_name VARCHAR(20) NOT NULL,
    mob_no VARCHAR(12) NOT NULL,
    student_email VARCHAR(30),
    student_address VARCHAR(50)
  )`;

// Queries
const query_insert = `INSERT INTO student_exp5 (student_uid, student_name, mob_no, student_email, student_address) VALUES (?, ?, ?, ?, ?)`;
const query_select_all = "SELECT * FROM student_exp5";
const query_select_by_id = "SELECT * FROM student_exp5 WHERE id = ?";
const query_delete = "DELETE FROM student_exp5 WHERE id = ?";
const query_update = `
  UPDATE student_exp5 
  SET student_uid = ?, student_name = ?, mob_no = ?, student_email = ?, student_address = ? 
  WHERE id = ?
`;

// Initialize Database
const initializeDB = async () => {
  try {
    await db.query(query_create_and_check_database);
    console.log("Database initialized successfully.");
  } catch (err) {
    console.error("Error initializing database:", err);
  }
};

// Function to get all records
const show_all_data = async () => {
  try {
    const [results] = await db.query(query_select_all);
    return results; // Return all rows
  } catch (err) {
    console.error("Error fetching data:", err);
    throw err;
  }
};

// Function to insert data
const insert_data = async (student_uid, student_name, mob_no, student_email, student_address) => {
  try {
    const [result] = await db.query(query_insert, [student_uid, student_name, mob_no, student_email, student_address]);
    return result;
  } catch (err) {
    console.error("Error inserting data:", err);
    throw err;
  }
};

// Function to delete data
const delete_data = async (id) => {
  try {
    const [result] = await db.query(query_delete, [id]);
    return result;
  } catch (err) {
    console.error("Error deleting data:", err);
    throw err;
  }
};

// Function to update data
const update_data = async (student_uid ,student_name, mob_no, student_email, student_address,id) => {
  try {
    const [result] = await db.query(query_update, [student_uid,student_name, mob_no, student_email, student_address,id]);
    return result;
  } catch (err) {
    console.error("Error updating data:", err);
    throw err;
  }
};

// Initialize database when file is loaded
initializeDB();

module.exports = {
  show_all_data,
  insert_data,
  delete_data,
  update_data,
};
