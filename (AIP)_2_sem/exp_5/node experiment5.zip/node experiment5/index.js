const express = require("express");
const cors = require("cors"); // Import the CORS middleware
const {
  show_all_data,
  insert_data,
  delete_data,
  update_data,
} = require("./db.js");

const app = express();
const port = 3000;

// Enable CORS
app.use(cors());

// Middleware to parse JSON requests
app.use(express.json());

// Route to fetch all data
app.get("/", async (req, res) => {
  try {
    const data = await show_all_data();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch data" });
  }
});

// Route to add new student record
app.post("/add", async (req, res) => {
  const { student_uid, student_name, mob_no, student_email, student_address } =
    req.body;

  console.log(
    student_uid,
    student_name,
    mob_no,
    student_email,
    student_address
  );
  // Validate input
  if (!student_uid || !student_name || !mob_no) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  try {
    const data = await insert_data(
      student_uid,
      student_name,
      mob_no,
      student_email,
      student_address
    );
    res.status(201).json({ message: "Record inserted successfully", data });
  } catch (error) {
    res.status(500).json({ error: "Failed to insert data" });
  }
});

// Route to delete a student record
app.delete("/:id", async (req, res) => {
  const { id } = req.params;

  try {
    // Check if record exists before deleting
    const existing = await show_all_data(); // Fetch all data
    const record = existing.find((item) => item.id === parseInt(id));
    if (!record) {
      return res.status(404).json({ error: "Record not found" });
    }

    const data = await delete_data(id);
    res.json({ message: "Deleted successfully", data });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete data" });
  }
});

// Route to update student record
app.put("/update/:id", async (req, res) => {
  const { id } = req.params;
  const { student_uid, student_name, mob_no, student_email, student_address } =
    req.body;

  // Validate input
  if (!id) {
    return res.status(400).json({ error: "ID is required for update" });
  }

  try {
    const data = await update_data(
      student_uid,
      student_name,
      mob_no,
      student_email,
      student_address,
      id
    );
    res.json({ message: "Updated successfully", data });
  } catch (error) {
    res.status(500).json({ error: "Failed to update data" });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
